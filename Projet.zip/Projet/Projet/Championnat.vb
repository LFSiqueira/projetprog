﻿Public Class Championnat
    Private Sub btnClass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClass.Click
        Me.Hide()  'le bouton classification permettre changer de formulaire
        Classification.Show()
    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click
        Application.Exit() 'boutton pour quitter le programme
    End Sub

    Private Sub cmbEqp1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp1.KeyPress
        e.Handled = True 'pour ne permettre pas aux usagers de taper le nom de l'équipe, il faut choisir dans la list
    End Sub
    Private Sub cmbEqp2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp2.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp3_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp3.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp4_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp4.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp5_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp5.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp6_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp6.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp7_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp7.KeyPress
        e.Handled = True
    End Sub
    Private Sub cmbEqp8_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbEqp8.KeyPress
        e.Handled = True
    End Sub
    Public Sub cmbEqp1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbEqp1.TextChanged
        cmbEqp1.DataSource = tblEquipes.Clone 'attribuer la source du combobox à partir du clone du tableau Equipes
        cmbEqp1.Text = cmbEqp1.SelectedIndex 'le texte choisi affiché correspond au index sellectionné dans le combobox
        For a = 1 To cmbEqp1.SelectedIndex 'quand l'index sellectionné est plus grand que 0 (l'index null)
            cmbEqp2.Enabled = True 'le programme enable le prochain combobox
            cmbEqp1.Enabled = False 'et disable le combobox actuel
        Next
    End Sub
    Public Sub cmbEqp2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbEqp2.TextChanged
        cmbEqp2.DataSource = tblEquipes
        cmbEqp2.Text = cmbEqp2.SelectedIndex
        For a = 1 To cmbEqp2.SelectedIndex
            cmbEqp3.Enabled = True
            cmbEqp2.Enabled = False
        Next
    End Sub
    Public Sub cmbEqp3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbEqp3.TextChanged
        cmbEqp3.DataSource = tblEquipes.Clone
        cmbEqp3.Text = cmbEqp1.SelectedIndex
        For a = 1 To cmbEqp3.SelectedIndex
            cmbEqp4.Enabled = True
            cmbEqp3.Enabled = False
        Next
    End Sub
   
End Class
