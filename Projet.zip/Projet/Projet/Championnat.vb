﻿Public Class Championnat
    Private Sub btnClass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClass.Click
        Me.Hide()  'le bouton classification permettre changer de formulaire
        Classification.Show()
    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click
        Application.Exit() 'boutton pour quitter le programme
    End Sub

    Private Sub gpbTour1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gpbTour1.Enter
        lblAvis.Text = "Veuillez choisir l'équipe dans la liste en haut, en suite cliquer sur choisir"
    End Sub
    Private Sub btnChoisir_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChoisir.Click
        For i = 0 To 7
            If txtEquipe1.Text = "" Then 'si txtEquipe1 est vide
                txtEquipe1.Text = cbListeEquipes.Text 'le txtEquipe1 prend la valeur de cbListeEquipes.texte
                tblEquipes(0) = CStr(txtEquipe1.Text) 'et garde la valeur dans l'index 0 du tableau
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem) 'remove l'item déjà choisi
                cbListeEquipes.Text = "" 'met le texte du combobox à vide
            ElseIf txtEquipe2.Text = "" Then
                txtEquipe2.Text = cbListeEquipes.Text
                tblEquipes(1) = CStr(txtEquipe2.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe3.Text = "" Then
                txtEquipe3.Text = cbListeEquipes.Text
                tblEquipes(2) = CStr(txtEquipe3.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe4.Text = "" Then
                txtEquipe4.Text = cbListeEquipes.Text
                tblEquipes(3) = CStr(txtEquipe4.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe5.Text = "" Then
                txtEquipe5.Text = cbListeEquipes.Text
                tblEquipes(4) = CStr(txtEquipe5.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe6.Text = "" Then
                txtEquipe6.Text = cbListeEquipes.Text
                tblEquipes(5) = CStr(txtEquipe6.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe7.Text = "" Then
                txtEquipe7.Text = cbListeEquipes.Text
                tblEquipes(6) = CStr(txtEquipe7.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe8.Text = "" Then
                txtEquipe8.Text = cbListeEquipes.Text
                tblEquipes(7) = CStr(txtEquipe8.Text)
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
                btnValider.Enabled = True
                lblAvis.Text = "Veuillez enregistrer les résultats des matchs (avec numéros entiers positifs)!"
            End If
        Next
    End Sub
    Private Sub cbListeEquipes_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cbListeEquipes.KeyPress
        e.Handled = True 'pour ne permettre pas aux usagers de taper le nom de l'équipe, il faut choisir dans la list
    End Sub
    
    Private Sub btnValider_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValider.Click
        ' If txtGolEqp1.Text = "" Or txtGolEqp2.Text = "" Or txtGolEqp3.Text = "" Or txtGolEqp4.Text = "" Or txtGolEqp5.Text = "" Or txtGolEqp6.Text = "" Or txtGolEqp7.Text = "" Or txtGolEqp8.Text = "" Then
        'MsgBox("Aucun champs vide valide!")
        'ElseIf IsNumeric(txtGolEqp1.Text) = False Or IsNumeric(txtGolEqp2.Text) = False Or IsNumeric(txtGolEqp3.Text) = False Or IsNumeric(txtGolEqp4.Text) = False Or IsNumeric(txtGolEqp5.Text) = False Or IsNumeric(txtGolEqp6.Text) = False Or IsNumeric(txtGolEqp7.Text) = False Or IsNumeric(txtGolEqp8.Text) = False Then
        'MsgBox("Veuillez entrer un chiffre numérique!")
        'ElseIf txtGolEqp1.Text < 0 Or txtGolEqp2.Text < 0 Or txtGolEqp3.Text < 0 Or txtGolEqp4.Text < 0 Or txtGolEqp5.Text < 0 Or txtGolEqp6.Text < 0 Or txtGolEqp7.Text < 0 Or txtGolEqp8.Text < 0 Then
        'MsgBox("Aucune valeur négative permise!")
        'End If
        intMatchE1 = CInt(txtGolEqp1.Text)
        intMatchE2 = CInt(txtGolEqp2.Text)
        intMatchE3 = CInt(txtGolEqp3.Text)
        intMatchE4 = CInt(txtGolEqp4.Text)
        intMatchE5 = CInt(txtGolEqp5.Text)
        intMatchE6 = CInt(txtGolEqp6.Text)
        intMatchE7 = CInt(txtGolEqp7.Text)
        intMatchE8 = CInt(txtGolEqp8.Text)
        If intMatchE1 > intMatchE2 Then
            lblGrpA.Text = txtEquipe2.Text
        ElseIf intMatchE1 < intMatchE2 Then
            lblGrpA.Text = txtEquipe2.Text
        ElseIf intMatchE1 = intMatchE2 Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp1.Text = ""
            txtGolEqp2.Text = ""
        End If
        If intMatchE3 > intMatchE4 Then
            lblGrpB.Text = txtEquipe3.Text
        ElseIf intMatchE3 < intMatchE4 Then
            lblGrpB.Text = txtEquipe4.Text
        ElseIf intMatchE3 = intMatchE4 Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp3.Text = ""
            txtGolEqp4.Text = ""
        End If
        If intMatchE5 > intMatchE6 Then
            lblGrpC.Text = txtEquipe5.Text
        ElseIf intMatchE5 < intMatchE6 Then
            lblGrpC.Text = txtEquipe6.Text
        ElseIf intMatchE5 = intMatchE6 Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp5.Text = ""
            txtGolEqp6.Text = ""
        End If
        If intMatchE7 > intMatchE8 Then
            lblGrpD.Text = txtEquipe7.Text
        ElseIf intMatchE7 < intMatchE8 Then
            lblGrpD.Text = txtEquipe8.Text
        ElseIf intMatchE7 = intMatchE8 Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp7.Text = ""
            txtGolEqp8.Text = ""
        End If
        txtGolGrpA.Enabled = True
        txtGolGrpB.Enabled = True
        txtGolGrpC.Enabled = True
        txtGolGrpD.Enabled = True
        btnChoisir.Enabled = False
        lblAvis.Text = "On est passé à demi-finale! Veuillez entrer les résultats des matchs!"
    End Sub

End Class

