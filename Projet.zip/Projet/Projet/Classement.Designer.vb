﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Classement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChampForm2 = New System.Windows.Forms.Label()
        Me.lblClass = New System.Windows.Forms.Label()
        Me.lblPodiumPremier = New System.Windows.Forms.Label()
        Me.lblPodiumDeux = New System.Windows.Forms.Label()
        Me.lblPodiumTrois = New System.Windows.Forms.Label()
        Me.lblPodiumQuatre = New System.Windows.Forms.Label()
        Me.btnMatch = New System.Windows.Forms.Button()
        Me.btnQuitter = New System.Windows.Forms.Button()
        Me.zero = New System.Windows.Forms.Label()
        Me.un = New System.Windows.Forms.Label()
        Me.deux = New System.Windows.Forms.Label()
        Me.trois = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblChampForm2
        '
        Me.lblChampForm2.AutoSize = True
        Me.lblChampForm2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChampForm2.ForeColor = System.Drawing.SystemColors.Highlight
        Me.lblChampForm2.Location = New System.Drawing.Point(233, 9)
        Me.lblChampForm2.Name = "lblChampForm2"
        Me.lblChampForm2.Size = New System.Drawing.Size(274, 24)
        Me.lblChampForm2.TabIndex = 1
        Me.lblChampForm2.Text = "Classement du championnat"
        '
        'lblClass
        '
        Me.lblClass.AutoSize = True
        Me.lblClass.ForeColor = System.Drawing.Color.Navy
        Me.lblClass.Location = New System.Drawing.Point(298, 33)
        Me.lblClass.Name = "lblClass"
        Me.lblClass.Size = New System.Drawing.Size(144, 13)
        Me.lblClass.TabIndex = 2
        Me.lblClass.Text = "Les quatres premières places"
        '
        'lblPodiumPremier
        '
        Me.lblPodiumPremier.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblPodiumPremier.Font = New System.Drawing.Font("Microsoft Sans Serif", 70.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPodiumPremier.ForeColor = System.Drawing.Color.SlateGray
        Me.lblPodiumPremier.Location = New System.Drawing.Point(194, 208)
        Me.lblPodiumPremier.Name = "lblPodiumPremier"
        Me.lblPodiumPremier.Size = New System.Drawing.Size(185, 107)
        Me.lblPodiumPremier.TabIndex = 3
        Me.lblPodiumPremier.Text = "1"
        Me.lblPodiumPremier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPodiumDeux
        '
        Me.lblPodiumDeux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblPodiumDeux.Font = New System.Drawing.Font("Microsoft Sans Serif", 60.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPodiumDeux.ForeColor = System.Drawing.Color.SlateGray
        Me.lblPodiumDeux.Location = New System.Drawing.Point(34, 297)
        Me.lblPodiumDeux.Name = "lblPodiumDeux"
        Me.lblPodiumDeux.Size = New System.Drawing.Size(245, 95)
        Me.lblPodiumDeux.TabIndex = 4
        Me.lblPodiumDeux.Text = "2     "
        Me.lblPodiumDeux.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPodiumTrois
        '
        Me.lblPodiumTrois.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblPodiumTrois.Font = New System.Drawing.Font("Microsoft Sans Serif", 50.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPodiumTrois.ForeColor = System.Drawing.Color.SlateGray
        Me.lblPodiumTrois.Location = New System.Drawing.Point(273, 315)
        Me.lblPodiumTrois.Name = "lblPodiumTrois"
        Me.lblPodiumTrois.Size = New System.Drawing.Size(264, 77)
        Me.lblPodiumTrois.TabIndex = 5
        Me.lblPodiumTrois.Text = "    3"
        Me.lblPodiumTrois.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPodiumQuatre
        '
        Me.lblPodiumQuatre.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblPodiumQuatre.Font = New System.Drawing.Font("Microsoft Sans Serif", 35.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPodiumQuatre.ForeColor = System.Drawing.Color.SlateGray
        Me.lblPodiumQuatre.Location = New System.Drawing.Point(511, 345)
        Me.lblPodiumQuatre.Name = "lblPodiumQuatre"
        Me.lblPodiumQuatre.Size = New System.Drawing.Size(189, 47)
        Me.lblPodiumQuatre.TabIndex = 6
        Me.lblPodiumQuatre.Text = "  4"
        Me.lblPodiumQuatre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnMatch
        '
        Me.btnMatch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMatch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnMatch.Location = New System.Drawing.Point(60, 479)
        Me.btnMatch.Name = "btnMatch"
        Me.btnMatch.Size = New System.Drawing.Size(193, 44)
        Me.btnMatch.TabIndex = 7
        Me.btnMatch.Text = "Matchs"
        Me.btnMatch.UseVisualStyleBackColor = True
        '
        'btnQuitter
        '
        Me.btnQuitter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuitter.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnQuitter.Location = New System.Drawing.Point(445, 479)
        Me.btnQuitter.Name = "btnQuitter"
        Me.btnQuitter.Size = New System.Drawing.Size(193, 44)
        Me.btnQuitter.TabIndex = 8
        Me.btnQuitter.Text = "Quitter"
        Me.btnQuitter.UseVisualStyleBackColor = True
        '
        'zero
        '
        Me.zero.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zero.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.zero.Location = New System.Drawing.Point(207, 161)
        Me.zero.Name = "zero"
        Me.zero.Size = New System.Drawing.Size(157, 42)
        Me.zero.TabIndex = 9
        Me.zero.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'un
        '
        Me.un.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.un.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.un.Location = New System.Drawing.Point(33, 252)
        Me.un.Name = "un"
        Me.un.Size = New System.Drawing.Size(157, 42)
        Me.un.TabIndex = 10
        Me.un.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'deux
        '
        Me.deux.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deux.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.deux.Location = New System.Drawing.Point(382, 270)
        Me.deux.Name = "deux"
        Me.deux.Size = New System.Drawing.Size(157, 42)
        Me.deux.TabIndex = 11
        Me.deux.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'trois
        '
        Me.trois.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.trois.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.trois.Location = New System.Drawing.Point(542, 300)
        Me.trois.Name = "trois"
        Me.trois.Size = New System.Drawing.Size(157, 42)
        Me.trois.TabIndex = 12
        Me.trois.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Classement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(734, 535)
        Me.Controls.Add(Me.trois)
        Me.Controls.Add(Me.deux)
        Me.Controls.Add(Me.un)
        Me.Controls.Add(Me.zero)
        Me.Controls.Add(Me.btnQuitter)
        Me.Controls.Add(Me.btnMatch)
        Me.Controls.Add(Me.lblPodiumQuatre)
        Me.Controls.Add(Me.lblPodiumTrois)
        Me.Controls.Add(Me.lblPodiumDeux)
        Me.Controls.Add(Me.lblPodiumPremier)
        Me.Controls.Add(Me.lblClass)
        Me.Controls.Add(Me.lblChampForm2)
        Me.Name = "Classement"
        Me.Text = "Classifitation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblChampForm2 As System.Windows.Forms.Label
    Friend WithEvents lblClass As System.Windows.Forms.Label
    Friend WithEvents lblPodiumPremier As System.Windows.Forms.Label
    Friend WithEvents lblPodiumDeux As System.Windows.Forms.Label
    Friend WithEvents lblPodiumTrois As System.Windows.Forms.Label
    Friend WithEvents lblPodiumQuatre As System.Windows.Forms.Label
    Friend WithEvents btnMatch As System.Windows.Forms.Button
    Friend WithEvents btnQuitter As System.Windows.Forms.Button
    Friend WithEvents zero As System.Windows.Forms.Label
    Friend WithEvents un As System.Windows.Forms.Label
    Friend WithEvents deux As System.Windows.Forms.Label
    Friend WithEvents trois As System.Windows.Forms.Label
End Class
