﻿Public Class Classement
    Private Sub btnMatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMatch.Click
        Me.Hide()  'le bouton classification permettre changer de formulaire
        Championnat.Show()
    End Sub
    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click
        Application.Exit() 'boutton pour quitter le programme
    End Sub

    Private Sub Classement_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        zero.Text = tblFinaliste(0) 'récupère les enregistrements du tableau finaliste et affiche dans l'ordre de classement
        un.Text = tblFinaliste(1)
        deux.Text = tblFinaliste(2)
        trois.Text = tblFinaliste(3)
    End Sub
End Class