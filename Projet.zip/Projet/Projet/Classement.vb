﻿Public Class Classement
    Private Sub btnMatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMatch.Click
        Me.Hide()  'le bouton classification permettre changer de formulaire
        Championnat.Show()
    End Sub
    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click
        Application.Exit() 'boutton pour quitter le programme
    End Sub

    Private Sub Classement_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For i = 0 To 3
            If index = 0 Then
                zero.Text = tblFinaliste(0) 'récupère les enregistrements du tableau finaliste et affiche dans l'ordre de classement
            ElseIf index = 1 Then
                un.Text = tblFinaliste(1)
            ElseIf index = 2 Then
                deux.Text = tblFinaliste(2)
            ElseIf index = 3 Then
                trois.Text = tblFinaliste(3)
            End If
            index = index + 1
        Next
    End Sub
End Class