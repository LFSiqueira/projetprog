﻿Public Class Championnat
    Private Sub btnClass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClass.Click
        tblGolFin(0) = CInt(txtGolFin1.Text) 'garder le buts des équipes dans la petite finale e la finale dans le tableau GolFin
        tblGolFin(1) = CInt(txtGolFin2.Text)
        tblGolFin(2) = CInt(txtGolFin3.Text)
        tblGolFin(3) = CInt(txtGolFin4.Text)
        If tblGolFin(0) > tblGolFin(1) Then 'compare des résultats
            tblFinaliste(0) = CStr(lblFin1.Text) 'et garde les équipes selon son classement (index) dans le tableau Finaliste
            tblFinaliste(1) = CStr(lblFin2.Text)
        ElseIf tblGolFin(0) < tblGolFin(1) Then
            tblFinaliste(0) = CStr(lblFin2.Text)
            tblFinaliste(1) = CStr(lblFin1.Text)
        ElseIf tblGolFin(0) = tblGolFin(1) Then 'si le résultat du match est null
            MsgBox("Aucun match null accepté!") 'affiche un message d'erreur
            txtGolFin1.Text = ""
            txtGolFin2.Text = ""
        End If
        If tblGolFin(2) > tblGolFin(3) Then
            tblFinaliste(2) = CStr(lblFin3.Text)
            tblFinaliste(3) = CStr(lblFin4.Text)
        ElseIf tblGolFin(2) < tblGolFin(3) Then
            tblFinaliste(2) = CStr(lblFin4.Text)
            tblFinaliste(3) = CStr(lblFin3.Text)
        ElseIf tblGolFin(2) = tblGolFin(3) Then
            MsgBox("Aucun match null accepté!")
            txtGolFin3.Text = ""
            txtGolFin4.Text = ""
        End If
        If tblFinaliste(0) <> "" And tblFinaliste(1) <> "" And tblFinaliste(2) <> "" And tblFinaliste(3) <> "" Then
            Me.Hide()  'le bouton classification permettre changer de formulaire
            Classement.Show()
        End If
    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click
        Application.Exit() 'boutton pour quitter le programme
    End Sub

    Private Sub gpbTour1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gpbTour1.Enter
        lblAvis.Text = "Veuillez choisir l'équipe dans la liste en haut, en suite cliquer sur choisir"
    End Sub
    Private Sub btnChoisir_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChoisir.Click
        For i = 0 To 7
            If txtEquipe1.Text = "" Then 'si txtEquipe1 est vide
                txtEquipe1.Text = cbListeEquipes.Text 'le txtEquipe1 prend la valeur de cbListeEquipes.texte
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem) 'remove l'item déjà choisi
                cbListeEquipes.Text = "" 'met le texte du combobox à vide
            ElseIf txtEquipe2.Text = "" Then
                txtEquipe2.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe3.Text = "" Then
                txtEquipe3.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe4.Text = "" Then
                txtEquipe4.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe5.Text = "" Then
                txtEquipe5.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe6.Text = "" Then
                txtEquipe6.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe7.Text = "" Then
                txtEquipe7.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
            ElseIf txtEquipe8.Text = "" Then
                txtEquipe8.Text = cbListeEquipes.Text
                cbListeEquipes.Items.Remove(cbListeEquipes.SelectedItem)
                cbListeEquipes.Text = ""
                btnValider.Enabled = True 'valide le btnValider
                lblAvis.Text = "Après enregistrer tous les résultats de matchs, appuyez sur Valider!"
            End If
        Next
    End Sub
    Private Sub cbListeEquipes_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cbListeEquipes.KeyPress
        e.Handled = True 'pour ne permettre pas aux usagers de taper le nom de l'équipe, il faut choisir dans la list
    End Sub
    
    Private Sub btnValider_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValider.Click
        btnChoisir.Enabled = False 'invalide le btnChoisir
        If txtGolEqp1.Text = "" Or txtGolEqp2.Text = "" Or txtGolEqp3.Text = "" Or txtGolEqp4.Text = "" Or txtGolEqp5.Text = "" Or txtGolEqp6.Text = "" Or txtGolEqp7.Text = "" Or txtGolEqp8.Text = "" Then 'vérifie les chmaps vides
            MsgBox("Veuillez respecter des consignes: les champs vides ne sont pas acceptés!") 'affiche une message d'erreur
        Else
            btnProchain.Enabled = True 'valide le btnProchain
            lblAvis.Text = "Veuillez appyer sur 'Prochaine étape' pour passer à la Demi-Finale!"
        End If
    End Sub
    Private Sub btnProchain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProchain.Click
        tblGol(0) = CInt(txtGolEqp1.Text) 'enregistre le txtGolEqp1 dans le tableau tblGol au index 0
        tblGol(1) = CInt(txtGolEqp2.Text)
        tblGol(2) = CInt(txtGolEqp3.Text)
        tblGol(3) = CInt(txtGolEqp4.Text)
        tblGol(4) = CInt(txtGolEqp5.Text)
        tblGol(5) = CInt(txtGolEqp6.Text)
        tblGol(6) = CInt(txtGolEqp7.Text)
        tblGol(7) = CInt(txtGolEqp8.Text)
        If tblGol(0) > tblGol(1) Then 'compare les deux valeurs
            lblGrpA.Text = txtEquipe1.Text 'et écrit le plus grand dans l'étiquette 
        ElseIf tblGol(0) < tblGol(1) Then
            lblGrpA.Text = txtEquipe2.Text
        ElseIf tblGol(0) = tblGol(1) Then 'si les deux résultats sont égaux
            MsgBox("Aucun match null accepté!") 'affiche un message d'erreur
            txtGolEqp1.Text = "" 'et efface les champs égaux pour permettre enregistrer des nouvelles valeurs
            txtGolEqp2.Text = ""
        End If
        If tblGol(2) > tblGol(3) Then
            lblGrpB.Text = txtEquipe3.Text
        ElseIf tblGol(2) < tblGol(3) Then
            lblGrpB.Text = txtEquipe4.Text
        ElseIf tblGol(2) = tblGol(3) Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp3.Text = ""
            txtGolEqp4.Text = ""
        End If
        If tblGol(4) > tblGol(5) Then
            lblGrpC.Text = txtEquipe5.Text
        ElseIf tblGol(4) < tblGol(5) Then
            lblGrpC.Text = txtEquipe6.Text
        ElseIf tblGol(4) = tblGol(5) Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp5.Text = ""
            txtGolEqp6.Text = ""
        End If
        If tblGol(6) > tblGol(7) Then
            lblGrpD.Text = txtEquipe7.Text
        ElseIf tblGol(6) < tblGol(7) Then
            lblGrpD.Text = txtEquipe8.Text
        ElseIf tblGol(6) = tblGol(7) Then
            MsgBox("Aucun match null accepté!")
            txtGolEqp7.Text = ""
            txtGolEqp8.Text = ""
        End If
        txtGolGrpA.Enabled = True 'active les champs texte de la prochaine étape
        txtGolGrpB.Enabled = True
        txtGolGrpC.Enabled = True
        txtGolGrpD.Enabled = True
        btnValider.Enabled = False 'inactive le btnValider
        btnValider2.Enabled = True 'active le btnValider2
        lblAvis.Text = "On est passé à demi-finale! Veuillez entrer les résultats des matchs!"
    End Sub

    Private Sub btnValider2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValider2.Click
        btnProchain.Enabled = False 'active le btnProchain
        If txtGolGrpA.Text = "" Or txtGolGrpB.Text = "" Or txtGolGrpC.Text = "" Or txtGolGrpD.Text = "" Then 'vérifie les chiffres vides
            MsgBox("Veuillez respecter des consignes: les champs vides ne sont pas acceptés!") 'affiche un message d'erreur
        Else
            btnProchain2.Enabled = True 'active le btnProchain2
            lblAvis.Text = "Veuillez appyer sur 'Prochaine étape' pour passer à la Finale!"
        End If
    End Sub

    Private Sub btnProchain2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProchain2.Click
        tblGolDf(0) = CInt(txtGolGrpA.Text)
        tblGolDf(1) = CInt(txtGolGrpB.Text)
        tblGolDf(2) = CInt(txtGolGrpC.Text)
        tblGolDf(3) = CInt(txtGolGrpD.Text)
        If tblGolDf(0) > tblGolDf(1) Then
            lblFin1.Text = lblGrpA.Text
            lblFin3.Text = lblGrpB.Text
        ElseIf tblGolDf(0) < tblGolDf(1) Then
            lblFin1.Text = lblGrpB.Text
            lblFin3.Text = lblGrpA.Text
        ElseIf tblGolDf(0) = tblGolDf(1) Then
            MsgBox("Aucun match null accepté!")
            txtGolGrpA.Text = ""
            txtGolGrpB.Text = ""
        End If
        If tblGolDf(2) > tblGolDf(3) Then
            lblFin2.Text = lblGrpC.Text
            lblFin4.Text = lblGrpD.Text
        ElseIf tblGolDf(2) < tblGolDf(3) Then
            lblFin2.Text = lblGrpD.Text
            lblFin4.Text = lblGrpC.Text
        ElseIf tblGolDf(2) = tblGolDf(3) Then
            MsgBox("Aucun match null accepté!")
            txtGolGrpC.Text = ""
            txtGolGrpD.Text = ""
        End If
        txtGolFin1.Enabled = True
        txtGolFin2.Enabled = True
        txtGolFin3.Enabled = True
        txtGolFin4.Enabled = True
        btnValider2.Enabled = False
        btnValiderFin.Enabled = True
        lblAvis.Text = "On est passé à finale! Veuillez entrer les résultats des matchs et les Valider!"
    End Sub

    Private Sub btnValiderFin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValiderFin.Click
        If txtGolFin1.Text = "" Or txtGolFin2.Text = "" Or txtGolFin3.Text = "" Or txtGolFin4.Text = "" Then
            MsgBox("Veuillez respecter des consignes: les champs vides ne sont pas acceptés!")
        Else
            btnValiderFin.Enabled = False
            btnProchain2.Enabled = False
            btnClass.Enabled = True
        End If
    End Sub

    Private Sub txtGoleqp1_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp1.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then 'pour invalider les entrés autres que les chiffres numériques entiers (fait pour chaque txtbox avec la quantité des buts)
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp2_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp2.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp3_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp3.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp4_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp4.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp5_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp5.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp6_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp6.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp7_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp7.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGoleqp8_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolEqp8.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolgrpa_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolGrpA.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolgrpb_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolGrpB.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolgrpc_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolGrpC.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolgrpd_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolGrpD.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolfin1_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolFin1.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolfin2_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolFin2.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolfin3_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolFin3.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Private Sub txtGolfin4_keypress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtGolFin4.KeyPress
        Dim allowedChars As String = "0123456789"
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
End Class

