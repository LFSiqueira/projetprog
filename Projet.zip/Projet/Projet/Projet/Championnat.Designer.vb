﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Championnat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ChampionnatBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblChamp = New System.Windows.Forms.Label()
        Me.gpbTour1 = New System.Windows.Forms.GroupBox()
        Me.btnProchain = New System.Windows.Forms.Button()
        Me.cbListeEquipes = New System.Windows.Forms.ComboBox()
        Me.txtEquipe8 = New System.Windows.Forms.TextBox()
        Me.txtEquipe7 = New System.Windows.Forms.TextBox()
        Me.txtEquipe6 = New System.Windows.Forms.TextBox()
        Me.txtEquipe5 = New System.Windows.Forms.TextBox()
        Me.txtEquipe4 = New System.Windows.Forms.TextBox()
        Me.txtEquipe3 = New System.Windows.Forms.TextBox()
        Me.txtEquipe2 = New System.Windows.Forms.TextBox()
        Me.txtEquipe1 = New System.Windows.Forms.TextBox()
        Me.btnChoisir = New System.Windows.Forms.Button()
        Me.txtGolEqp8 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp7 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp6 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp5 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp4 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp3 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp2 = New System.Windows.Forms.TextBox()
        Me.txtGolEqp1 = New System.Windows.Forms.TextBox()
        Me.lblVersus4 = New System.Windows.Forms.Label()
        Me.lblVersus3 = New System.Windows.Forms.Label()
        Me.lblVersus2 = New System.Windows.Forms.Label()
        Me.lblVersus1 = New System.Windows.Forms.Label()
        Me.btnValider = New System.Windows.Forms.Button()
        Me.lblAvis = New System.Windows.Forms.Label()
        Me.grpDemiFinale = New System.Windows.Forms.GroupBox()
        Me.btnProchain2 = New System.Windows.Forms.Button()
        Me.lblVersus5 = New System.Windows.Forms.Label()
        Me.txtGolGrpD = New System.Windows.Forms.TextBox()
        Me.txtGolGrpC = New System.Windows.Forms.TextBox()
        Me.txtGolGrpB = New System.Windows.Forms.TextBox()
        Me.txtGolGrpA = New System.Windows.Forms.TextBox()
        Me.lblVersus6 = New System.Windows.Forms.Label()
        Me.btnValider2 = New System.Windows.Forms.Button()
        Me.lblGrpD = New System.Windows.Forms.Label()
        Me.lblGrpC = New System.Windows.Forms.Label()
        Me.lblGrpB = New System.Windows.Forms.Label()
        Me.lblGrpA = New System.Windows.Forms.Label()
        Me.btnClass = New System.Windows.Forms.Button()
        Me.btnQuitter = New System.Windows.Forms.Button()
        Me.lblFin1 = New System.Windows.Forms.Label()
        Me.lblFin2 = New System.Windows.Forms.Label()
        Me.lblFin3 = New System.Windows.Forms.Label()
        Me.lblFin4 = New System.Windows.Forms.Label()
        Me.grbFinale = New System.Windows.Forms.GroupBox()
        Me.lblPetiteFinale = New System.Windows.Forms.Label()
        Me.lblChampion = New System.Windows.Forms.Label()
        Me.btnValiderFin = New System.Windows.Forms.Button()
        Me.txtGolFin4 = New System.Windows.Forms.TextBox()
        Me.txtGolFin3 = New System.Windows.Forms.TextBox()
        Me.txtGolFin2 = New System.Windows.Forms.TextBox()
        Me.txtGolFin1 = New System.Windows.Forms.TextBox()
        Me.lblVersus8 = New System.Windows.Forms.Label()
        Me.lblVersus7 = New System.Windows.Forms.Label()
        CType(Me.ChampionnatBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gpbTour1.SuspendLayout()
        Me.grpDemiFinale.SuspendLayout()
        Me.grbFinale.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblChamp
        '
        Me.lblChamp.AutoSize = True
        Me.lblChamp.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChamp.ForeColor = System.Drawing.SystemColors.Highlight
        Me.lblChamp.Location = New System.Drawing.Point(303, 9)
        Me.lblChamp.Name = "lblChamp"
        Me.lblChamp.Size = New System.Drawing.Size(232, 24)
        Me.lblChamp.TabIndex = 0
        Me.lblChamp.Text = "Championnat de soccer"
        '
        'gpbTour1
        '
        Me.gpbTour1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.gpbTour1.Controls.Add(Me.btnProchain)
        Me.gpbTour1.Controls.Add(Me.cbListeEquipes)
        Me.gpbTour1.Controls.Add(Me.txtEquipe8)
        Me.gpbTour1.Controls.Add(Me.txtEquipe7)
        Me.gpbTour1.Controls.Add(Me.txtEquipe6)
        Me.gpbTour1.Controls.Add(Me.txtEquipe5)
        Me.gpbTour1.Controls.Add(Me.txtEquipe4)
        Me.gpbTour1.Controls.Add(Me.txtEquipe3)
        Me.gpbTour1.Controls.Add(Me.txtEquipe2)
        Me.gpbTour1.Controls.Add(Me.txtEquipe1)
        Me.gpbTour1.Controls.Add(Me.btnChoisir)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp8)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp7)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp6)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp5)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp4)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp3)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp2)
        Me.gpbTour1.Controls.Add(Me.txtGolEqp1)
        Me.gpbTour1.Controls.Add(Me.lblVersus4)
        Me.gpbTour1.Controls.Add(Me.lblVersus3)
        Me.gpbTour1.Controls.Add(Me.lblVersus2)
        Me.gpbTour1.Controls.Add(Me.lblVersus1)
        Me.gpbTour1.Controls.Add(Me.btnValider)
        Me.gpbTour1.Location = New System.Drawing.Point(25, 81)
        Me.gpbTour1.Name = "gpbTour1"
        Me.gpbTour1.Size = New System.Drawing.Size(770, 204)
        Me.gpbTour1.TabIndex = 1
        Me.gpbTour1.TabStop = False
        Me.gpbTour1.Text = "Premier Tour"
        '
        'btnProchain
        '
        Me.btnProchain.Enabled = False
        Me.btnProchain.Location = New System.Drawing.Point(453, 174)
        Me.btnProchain.Name = "btnProchain"
        Me.btnProchain.Size = New System.Drawing.Size(117, 23)
        Me.btnProchain.TabIndex = 52
        Me.btnProchain.Text = "Prochaine étape"
        Me.btnProchain.UseVisualStyleBackColor = True
        '
        'cbListeEquipes
        '
        Me.cbListeEquipes.FormattingEnabled = True
        Me.cbListeEquipes.Items.AddRange(New Object() {"Allemagne", "Anglaterre", "Brésil", "Croatie", "Espagne", "France", "Italie", "Suisse"})
        Me.cbListeEquipes.Location = New System.Drawing.Point(318, 10)
        Me.cbListeEquipes.Name = "cbListeEquipes"
        Me.cbListeEquipes.Size = New System.Drawing.Size(131, 24)
        Me.cbListeEquipes.TabIndex = 51
        '
        'txtEquipe8
        '
        Me.txtEquipe8.Enabled = False
        Me.txtEquipe8.Location = New System.Drawing.Point(632, 103)
        Me.txtEquipe8.Name = "txtEquipe8"
        Me.txtEquipe8.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe8.TabIndex = 50
        '
        'txtEquipe7
        '
        Me.txtEquipe7.Enabled = False
        Me.txtEquipe7.Location = New System.Drawing.Point(470, 103)
        Me.txtEquipe7.Name = "txtEquipe7"
        Me.txtEquipe7.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe7.TabIndex = 49
        '
        'txtEquipe6
        '
        Me.txtEquipe6.Enabled = False
        Me.txtEquipe6.Location = New System.Drawing.Point(197, 103)
        Me.txtEquipe6.Name = "txtEquipe6"
        Me.txtEquipe6.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe6.TabIndex = 48
        '
        'txtEquipe5
        '
        Me.txtEquipe5.Enabled = False
        Me.txtEquipe5.Location = New System.Drawing.Point(37, 106)
        Me.txtEquipe5.Name = "txtEquipe5"
        Me.txtEquipe5.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe5.TabIndex = 47
        '
        'txtEquipe4
        '
        Me.txtEquipe4.Enabled = False
        Me.txtEquipe4.Location = New System.Drawing.Point(632, 30)
        Me.txtEquipe4.Name = "txtEquipe4"
        Me.txtEquipe4.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe4.TabIndex = 46
        '
        'txtEquipe3
        '
        Me.txtEquipe3.Enabled = False
        Me.txtEquipe3.Location = New System.Drawing.Point(470, 30)
        Me.txtEquipe3.Name = "txtEquipe3"
        Me.txtEquipe3.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe3.TabIndex = 45
        '
        'txtEquipe2
        '
        Me.txtEquipe2.Enabled = False
        Me.txtEquipe2.Location = New System.Drawing.Point(197, 30)
        Me.txtEquipe2.Name = "txtEquipe2"
        Me.txtEquipe2.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe2.TabIndex = 44
        '
        'txtEquipe1
        '
        Me.txtEquipe1.Enabled = False
        Me.txtEquipe1.Location = New System.Drawing.Point(37, 33)
        Me.txtEquipe1.Name = "txtEquipe1"
        Me.txtEquipe1.Size = New System.Drawing.Size(100, 22)
        Me.txtEquipe1.TabIndex = 43
        '
        'btnChoisir
        '
        Me.btnChoisir.Location = New System.Drawing.Point(318, 173)
        Me.btnChoisir.Name = "btnChoisir"
        Me.btnChoisir.Size = New System.Drawing.Size(114, 24)
        Me.btnChoisir.TabIndex = 39
        Me.btnChoisir.Text = "Choisir équipe"
        Me.btnChoisir.UseVisualStyleBackColor = True
        '
        'txtGolEqp8
        '
        Me.txtGolEqp8.Location = New System.Drawing.Point(632, 136)
        Me.txtGolEqp8.Name = "txtGolEqp8"
        Me.txtGolEqp8.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp8.TabIndex = 30
        '
        'txtGolEqp7
        '
        Me.txtGolEqp7.Location = New System.Drawing.Point(551, 136)
        Me.txtGolEqp7.Name = "txtGolEqp7"
        Me.txtGolEqp7.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp7.TabIndex = 29
        '
        'txtGolEqp6
        '
        Me.txtGolEqp6.Location = New System.Drawing.Point(197, 136)
        Me.txtGolEqp6.Name = "txtGolEqp6"
        Me.txtGolEqp6.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp6.TabIndex = 28
        '
        'txtGolEqp5
        '
        Me.txtGolEqp5.Location = New System.Drawing.Point(105, 136)
        Me.txtGolEqp5.Name = "txtGolEqp5"
        Me.txtGolEqp5.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp5.TabIndex = 27
        '
        'txtGolEqp4
        '
        Me.txtGolEqp4.Location = New System.Drawing.Point(632, 63)
        Me.txtGolEqp4.Name = "txtGolEqp4"
        Me.txtGolEqp4.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp4.TabIndex = 26
        '
        'txtGolEqp3
        '
        Me.txtGolEqp3.Location = New System.Drawing.Point(551, 63)
        Me.txtGolEqp3.Name = "txtGolEqp3"
        Me.txtGolEqp3.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp3.TabIndex = 25
        '
        'txtGolEqp2
        '
        Me.txtGolEqp2.Location = New System.Drawing.Point(197, 63)
        Me.txtGolEqp2.Name = "txtGolEqp2"
        Me.txtGolEqp2.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp2.TabIndex = 24
        '
        'txtGolEqp1
        '
        Me.txtGolEqp1.Location = New System.Drawing.Point(105, 63)
        Me.txtGolEqp1.Name = "txtGolEqp1"
        Me.txtGolEqp1.Size = New System.Drawing.Size(32, 22)
        Me.txtGolEqp1.TabIndex = 23
        '
        'lblVersus4
        '
        Me.lblVersus4.AutoSize = True
        Me.lblVersus4.Location = New System.Drawing.Point(596, 109)
        Me.lblVersus4.Name = "lblVersus4"
        Me.lblVersus4.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus4.TabIndex = 22
        Me.lblVersus4.Text = "X"
        '
        'lblVersus3
        '
        Me.lblVersus3.AutoSize = True
        Me.lblVersus3.Location = New System.Drawing.Point(158, 109)
        Me.lblVersus3.Name = "lblVersus3"
        Me.lblVersus3.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus3.TabIndex = 21
        Me.lblVersus3.Text = "X"
        '
        'lblVersus2
        '
        Me.lblVersus2.AutoSize = True
        Me.lblVersus2.Location = New System.Drawing.Point(596, 36)
        Me.lblVersus2.Name = "lblVersus2"
        Me.lblVersus2.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus2.TabIndex = 20
        Me.lblVersus2.Text = "X"
        '
        'lblVersus1
        '
        Me.lblVersus1.AutoSize = True
        Me.lblVersus1.Location = New System.Drawing.Point(158, 36)
        Me.lblVersus1.Name = "lblVersus1"
        Me.lblVersus1.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus1.TabIndex = 19
        Me.lblVersus1.Text = "X"
        '
        'btnValider
        '
        Me.btnValider.Enabled = False
        Me.btnValider.Location = New System.Drawing.Point(222, 173)
        Me.btnValider.Name = "btnValider"
        Me.btnValider.Size = New System.Drawing.Size(75, 23)
        Me.btnValider.TabIndex = 0
        Me.btnValider.Text = "Valider"
        Me.btnValider.UseVisualStyleBackColor = True
        '
        'lblAvis
        '
        Me.lblAvis.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvis.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblAvis.Location = New System.Drawing.Point(22, 61)
        Me.lblAvis.Name = "lblAvis"
        Me.lblAvis.Size = New System.Drawing.Size(773, 17)
        Me.lblAvis.TabIndex = 42
        '
        'grpDemiFinale
        '
        Me.grpDemiFinale.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.grpDemiFinale.Controls.Add(Me.btnProchain2)
        Me.grpDemiFinale.Controls.Add(Me.lblVersus5)
        Me.grpDemiFinale.Controls.Add(Me.txtGolGrpD)
        Me.grpDemiFinale.Controls.Add(Me.txtGolGrpC)
        Me.grpDemiFinale.Controls.Add(Me.txtGolGrpB)
        Me.grpDemiFinale.Controls.Add(Me.txtGolGrpA)
        Me.grpDemiFinale.Controls.Add(Me.lblVersus6)
        Me.grpDemiFinale.Controls.Add(Me.btnValider2)
        Me.grpDemiFinale.Controls.Add(Me.lblGrpD)
        Me.grpDemiFinale.Controls.Add(Me.lblGrpC)
        Me.grpDemiFinale.Controls.Add(Me.lblGrpB)
        Me.grpDemiFinale.Controls.Add(Me.lblGrpA)
        Me.grpDemiFinale.Location = New System.Drawing.Point(25, 291)
        Me.grpDemiFinale.Name = "grpDemiFinale"
        Me.grpDemiFinale.Size = New System.Drawing.Size(770, 100)
        Me.grpDemiFinale.TabIndex = 2
        Me.grpDemiFinale.TabStop = False
        Me.grpDemiFinale.Text = "Demi-finale"
        '
        'btnProchain2
        '
        Me.btnProchain2.Enabled = False
        Me.btnProchain2.Location = New System.Drawing.Point(366, 71)
        Me.btnProchain2.Name = "btnProchain2"
        Me.btnProchain2.Size = New System.Drawing.Size(117, 23)
        Me.btnProchain2.TabIndex = 53
        Me.btnProchain2.Text = "Prochaine étape"
        Me.btnProchain2.UseVisualStyleBackColor = True
        '
        'lblVersus5
        '
        Me.lblVersus5.AutoSize = True
        Me.lblVersus5.Location = New System.Drawing.Point(158, 32)
        Me.lblVersus5.Name = "lblVersus5"
        Me.lblVersus5.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus5.TabIndex = 18
        Me.lblVersus5.Text = "X"
        '
        'txtGolGrpD
        '
        Me.txtGolGrpD.Enabled = False
        Me.txtGolGrpD.Location = New System.Drawing.Point(648, 57)
        Me.txtGolGrpD.Name = "txtGolGrpD"
        Me.txtGolGrpD.Size = New System.Drawing.Size(32, 22)
        Me.txtGolGrpD.TabIndex = 17
        '
        'txtGolGrpC
        '
        Me.txtGolGrpC.Enabled = False
        Me.txtGolGrpC.Location = New System.Drawing.Point(522, 57)
        Me.txtGolGrpC.Name = "txtGolGrpC"
        Me.txtGolGrpC.Size = New System.Drawing.Size(32, 22)
        Me.txtGolGrpC.TabIndex = 16
        '
        'txtGolGrpB
        '
        Me.txtGolGrpB.Enabled = False
        Me.txtGolGrpB.Location = New System.Drawing.Point(213, 57)
        Me.txtGolGrpB.Name = "txtGolGrpB"
        Me.txtGolGrpB.Size = New System.Drawing.Size(32, 22)
        Me.txtGolGrpB.TabIndex = 15
        '
        'txtGolGrpA
        '
        Me.txtGolGrpA.Enabled = False
        Me.txtGolGrpA.Location = New System.Drawing.Point(79, 57)
        Me.txtGolGrpA.Name = "txtGolGrpA"
        Me.txtGolGrpA.Size = New System.Drawing.Size(32, 22)
        Me.txtGolGrpA.TabIndex = 14
        '
        'lblVersus6
        '
        Me.lblVersus6.AutoSize = True
        Me.lblVersus6.Location = New System.Drawing.Point(596, 32)
        Me.lblVersus6.Name = "lblVersus6"
        Me.lblVersus6.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus6.TabIndex = 7
        Me.lblVersus6.Text = "X"
        '
        'btnValider2
        '
        Me.btnValider2.Enabled = False
        Me.btnValider2.Location = New System.Drawing.Point(270, 71)
        Me.btnValider2.Name = "btnValider2"
        Me.btnValider2.Size = New System.Drawing.Size(75, 23)
        Me.btnValider2.TabIndex = 5
        Me.btnValider2.Text = "Valider"
        Me.btnValider2.UseVisualStyleBackColor = True
        '
        'lblGrpD
        '
        Me.lblGrpD.AutoSize = True
        Me.lblGrpD.BackColor = System.Drawing.SystemColors.Window
        Me.lblGrpD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrpD.Enabled = False
        Me.lblGrpD.Location = New System.Drawing.Point(690, 32)
        Me.lblGrpD.Name = "lblGrpD"
        Me.lblGrpD.Size = New System.Drawing.Size(2, 18)
        Me.lblGrpD.TabIndex = 4
        '
        'lblGrpC
        '
        Me.lblGrpC.AutoSize = True
        Me.lblGrpC.BackColor = System.Drawing.SystemColors.Window
        Me.lblGrpC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrpC.Enabled = False
        Me.lblGrpC.Location = New System.Drawing.Point(491, 32)
        Me.lblGrpC.Name = "lblGrpC"
        Me.lblGrpC.Size = New System.Drawing.Size(2, 18)
        Me.lblGrpC.TabIndex = 3
        '
        'lblGrpB
        '
        Me.lblGrpB.AutoSize = True
        Me.lblGrpB.BackColor = System.Drawing.SystemColors.Window
        Me.lblGrpB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrpB.Enabled = False
        Me.lblGrpB.Location = New System.Drawing.Point(263, 30)
        Me.lblGrpB.Name = "lblGrpB"
        Me.lblGrpB.Size = New System.Drawing.Size(2, 18)
        Me.lblGrpB.TabIndex = 2
        '
        'lblGrpA
        '
        Me.lblGrpA.AutoSize = True
        Me.lblGrpA.BackColor = System.Drawing.SystemColors.Window
        Me.lblGrpA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrpA.Enabled = False
        Me.lblGrpA.Location = New System.Drawing.Point(40, 32)
        Me.lblGrpA.Name = "lblGrpA"
        Me.lblGrpA.Size = New System.Drawing.Size(2, 18)
        Me.lblGrpA.TabIndex = 1
        '
        'btnClass
        '
        Me.btnClass.Enabled = False
        Me.btnClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClass.Location = New System.Drawing.Point(496, 562)
        Me.btnClass.Name = "btnClass"
        Me.btnClass.Size = New System.Drawing.Size(193, 44)
        Me.btnClass.TabIndex = 4
        Me.btnClass.Text = "Classement"
        Me.btnClass.UseVisualStyleBackColor = True
        '
        'btnQuitter
        '
        Me.btnQuitter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuitter.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnQuitter.Location = New System.Drawing.Point(130, 562)
        Me.btnQuitter.Name = "btnQuitter"
        Me.btnQuitter.Size = New System.Drawing.Size(193, 44)
        Me.btnQuitter.TabIndex = 5
        Me.btnQuitter.Text = "Quitter"
        Me.btnQuitter.UseVisualStyleBackColor = True
        '
        'lblFin1
        '
        Me.lblFin1.AutoSize = True
        Me.lblFin1.BackColor = System.Drawing.SystemColors.Window
        Me.lblFin1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFin1.Enabled = False
        Me.lblFin1.Location = New System.Drawing.Point(40, 37)
        Me.lblFin1.Name = "lblFin1"
        Me.lblFin1.Size = New System.Drawing.Size(2, 18)
        Me.lblFin1.TabIndex = 7
        '
        'lblFin2
        '
        Me.lblFin2.AutoSize = True
        Me.lblFin2.BackColor = System.Drawing.SystemColors.Window
        Me.lblFin2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFin2.Enabled = False
        Me.lblFin2.Location = New System.Drawing.Point(263, 37)
        Me.lblFin2.Name = "lblFin2"
        Me.lblFin2.Size = New System.Drawing.Size(2, 18)
        Me.lblFin2.TabIndex = 8
        '
        'lblFin3
        '
        Me.lblFin3.AutoSize = True
        Me.lblFin3.BackColor = System.Drawing.SystemColors.Window
        Me.lblFin3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFin3.Enabled = False
        Me.lblFin3.Location = New System.Drawing.Point(491, 37)
        Me.lblFin3.Name = "lblFin3"
        Me.lblFin3.Size = New System.Drawing.Size(2, 18)
        Me.lblFin3.TabIndex = 9
        '
        'lblFin4
        '
        Me.lblFin4.AutoSize = True
        Me.lblFin4.BackColor = System.Drawing.SystemColors.Window
        Me.lblFin4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFin4.Enabled = False
        Me.lblFin4.Location = New System.Drawing.Point(689, 37)
        Me.lblFin4.Name = "lblFin4"
        Me.lblFin4.Size = New System.Drawing.Size(2, 18)
        Me.lblFin4.TabIndex = 10
        '
        'grbFinale
        '
        Me.grbFinale.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.grbFinale.Controls.Add(Me.lblPetiteFinale)
        Me.grbFinale.Controls.Add(Me.lblChampion)
        Me.grbFinale.Controls.Add(Me.btnValiderFin)
        Me.grbFinale.Controls.Add(Me.txtGolFin4)
        Me.grbFinale.Controls.Add(Me.txtGolFin3)
        Me.grbFinale.Controls.Add(Me.txtGolFin2)
        Me.grbFinale.Controls.Add(Me.txtGolFin1)
        Me.grbFinale.Controls.Add(Me.lblVersus8)
        Me.grbFinale.Controls.Add(Me.lblVersus7)
        Me.grbFinale.Controls.Add(Me.lblFin4)
        Me.grbFinale.Controls.Add(Me.lblFin3)
        Me.grbFinale.Controls.Add(Me.lblFin2)
        Me.grbFinale.Controls.Add(Me.lblFin1)
        Me.grbFinale.Location = New System.Drawing.Point(25, 407)
        Me.grbFinale.Name = "grbFinale"
        Me.grbFinale.Size = New System.Drawing.Size(770, 121)
        Me.grbFinale.TabIndex = 3
        Me.grbFinale.TabStop = False
        Me.grbFinale.Text = "Finale"
        '
        'lblPetiteFinale
        '
        Me.lblPetiteFinale.AutoSize = True
        Me.lblPetiteFinale.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPetiteFinale.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPetiteFinale.Location = New System.Drawing.Point(564, 11)
        Me.lblPetiteFinale.Name = "lblPetiteFinale"
        Me.lblPetiteFinale.Size = New System.Drawing.Size(75, 13)
        Me.lblPetiteFinale.TabIndex = 19
        Me.lblPetiteFinale.Text = "Petite finale"
        '
        'lblChampion
        '
        Me.lblChampion.AutoSize = True
        Me.lblChampion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChampion.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblChampion.Location = New System.Drawing.Point(88, 12)
        Me.lblChampion.Name = "lblChampion"
        Me.lblChampion.Size = New System.Drawing.Size(128, 13)
        Me.lblChampion.TabIndex = 18
        Me.lblChampion.Text = "Match des champions"
        '
        'btnValiderFin
        '
        Me.btnValiderFin.Enabled = False
        Me.btnValiderFin.Location = New System.Drawing.Point(342, 92)
        Me.btnValiderFin.Name = "btnValiderFin"
        Me.btnValiderFin.Size = New System.Drawing.Size(75, 23)
        Me.btnValiderFin.TabIndex = 17
        Me.btnValiderFin.Text = "Valider"
        Me.btnValiderFin.UseVisualStyleBackColor = True
        '
        'txtGolFin4
        '
        Me.txtGolFin4.Enabled = False
        Me.txtGolFin4.Location = New System.Drawing.Point(648, 72)
        Me.txtGolFin4.Name = "txtGolFin4"
        Me.txtGolFin4.Size = New System.Drawing.Size(32, 22)
        Me.txtGolFin4.TabIndex = 16
        '
        'txtGolFin3
        '
        Me.txtGolFin3.Enabled = False
        Me.txtGolFin3.Location = New System.Drawing.Point(522, 72)
        Me.txtGolFin3.Name = "txtGolFin3"
        Me.txtGolFin3.Size = New System.Drawing.Size(32, 22)
        Me.txtGolFin3.TabIndex = 15
        '
        'txtGolFin2
        '
        Me.txtGolFin2.Enabled = False
        Me.txtGolFin2.Location = New System.Drawing.Point(213, 72)
        Me.txtGolFin2.Name = "txtGolFin2"
        Me.txtGolFin2.Size = New System.Drawing.Size(32, 22)
        Me.txtGolFin2.TabIndex = 14
        '
        'txtGolFin1
        '
        Me.txtGolFin1.Enabled = False
        Me.txtGolFin1.Location = New System.Drawing.Point(79, 72)
        Me.txtGolFin1.Name = "txtGolFin1"
        Me.txtGolFin1.Size = New System.Drawing.Size(32, 22)
        Me.txtGolFin1.TabIndex = 13
        '
        'lblVersus8
        '
        Me.lblVersus8.AutoSize = True
        Me.lblVersus8.Location = New System.Drawing.Point(596, 37)
        Me.lblVersus8.Name = "lblVersus8"
        Me.lblVersus8.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus8.TabIndex = 12
        Me.lblVersus8.Text = "X"
        '
        'lblVersus7
        '
        Me.lblVersus7.AutoSize = True
        Me.lblVersus7.Location = New System.Drawing.Point(158, 37)
        Me.lblVersus7.Name = "lblVersus7"
        Me.lblVersus7.Size = New System.Drawing.Size(16, 16)
        Me.lblVersus7.TabIndex = 11
        Me.lblVersus7.Text = "X"
        '
        'Championnat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(821, 631)
        Me.Controls.Add(Me.btnQuitter)
        Me.Controls.Add(Me.btnClass)
        Me.Controls.Add(Me.grbFinale)
        Me.Controls.Add(Me.grpDemiFinale)
        Me.Controls.Add(Me.gpbTour1)
        Me.Controls.Add(Me.lblChamp)
        Me.Controls.Add(Me.lblAvis)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Championnat"
        Me.Text = "Form1"
        CType(Me.ChampionnatBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gpbTour1.ResumeLayout(False)
        Me.gpbTour1.PerformLayout()
        Me.grpDemiFinale.ResumeLayout(False)
        Me.grpDemiFinale.PerformLayout()
        Me.grbFinale.ResumeLayout(False)
        Me.grbFinale.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblChamp As System.Windows.Forms.Label
    Friend WithEvents gpbTour1 As System.Windows.Forms.GroupBox
    Friend WithEvents grpDemiFinale As System.Windows.Forms.GroupBox
    Friend WithEvents btnClass As System.Windows.Forms.Button
    Friend WithEvents btnQuitter As System.Windows.Forms.Button
    Friend WithEvents btnValider As System.Windows.Forms.Button
    Friend WithEvents btnValider2 As System.Windows.Forms.Button
    Friend WithEvents lblGrpD As System.Windows.Forms.Label
    Friend WithEvents lblGrpC As System.Windows.Forms.Label
    Friend WithEvents lblGrpB As System.Windows.Forms.Label
    Friend WithEvents lblGrpA As System.Windows.Forms.Label
    Friend WithEvents txtGolGrpD As System.Windows.Forms.TextBox
    Friend WithEvents txtGolGrpC As System.Windows.Forms.TextBox
    Friend WithEvents txtGolGrpB As System.Windows.Forms.TextBox
    Friend WithEvents txtGolGrpA As System.Windows.Forms.TextBox
    Friend WithEvents lblVersus6 As System.Windows.Forms.Label
    Friend WithEvents lblFin1 As System.Windows.Forms.Label
    Friend WithEvents lblFin2 As System.Windows.Forms.Label
    Friend WithEvents lblFin3 As System.Windows.Forms.Label
    Friend WithEvents lblFin4 As System.Windows.Forms.Label
    Friend WithEvents grbFinale As System.Windows.Forms.GroupBox
    Friend WithEvents txtGolFin4 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolFin3 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolFin2 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolFin1 As System.Windows.Forms.TextBox
    Friend WithEvents lblVersus8 As System.Windows.Forms.Label
    Friend WithEvents lblVersus7 As System.Windows.Forms.Label
    Friend WithEvents lblVersus2 As System.Windows.Forms.Label
    Friend WithEvents lblVersus1 As System.Windows.Forms.Label
    Friend WithEvents lblVersus5 As System.Windows.Forms.Label
    Friend WithEvents lblVersus4 As System.Windows.Forms.Label
    Friend WithEvents lblVersus3 As System.Windows.Forms.Label
    Friend WithEvents txtGolEqp8 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp7 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp6 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp5 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp4 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp3 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp2 As System.Windows.Forms.TextBox
    Friend WithEvents txtGolEqp1 As System.Windows.Forms.TextBox
    Private WithEvents ChampionnatBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents btnChoisir As System.Windows.Forms.Button
    Friend WithEvents lblAvis As System.Windows.Forms.Label
    Friend WithEvents txtEquipe8 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe7 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe6 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe5 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe4 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe3 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe2 As System.Windows.Forms.TextBox
    Friend WithEvents txtEquipe1 As System.Windows.Forms.TextBox
    Friend WithEvents cbListeEquipes As System.Windows.Forms.ComboBox
    Friend WithEvents btnProchain As System.Windows.Forms.Button
    Friend WithEvents btnProchain2 As System.Windows.Forms.Button
    Friend WithEvents lblPetiteFinale As System.Windows.Forms.Label
    Friend WithEvents lblChampion As System.Windows.Forms.Label
    Friend WithEvents btnValiderFin As System.Windows.Forms.Button

End Class
