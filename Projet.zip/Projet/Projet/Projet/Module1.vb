﻿Module Module1
    Public tblGol(7) As Integer
    Public tblGolDf(3) As Integer
    Public tblGolFin(3) As Integer
    Public tblFinaliste(3) As String
    Public index As Integer = 0
End Module
