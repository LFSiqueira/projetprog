﻿Module Module1
    Public intMatchE1 As Integer = 0
    Public intMatchE2 As Integer = 0
    Public intMatchE3 As Integer = 0
    Public intMatchE4 As Integer = 0
    Public intMatchE5 As Integer = 0
    Public intMatchE6 As Integer = 0
    Public intMatchE7 As Integer = 0
    Public intMatchE8 As Integer = 0
    Public intDfGrpA As Integer = 0
    Public intDfGrpB As Integer = 0
    Public intDfGrpC As Integer = 0
    Public intDfGrpD As Integer = 0
    Public intGolFin1 As Integer = 0
    Public intGolFin2 As Integer = 0
    Public intGolFin3 As Integer = 0
    Public intGolFin4 As Integer = 0
    Public tblEquipes(7) As String
    Public index As Integer
   
End Module
